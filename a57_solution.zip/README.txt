READ ME 

Requirements:
- 3 Ubuntu VM (22.04)
- 2 Virtual Switches

One called CORK-WEB: with Django 3.1.3, Django-Crispy-Forms 1.9.0, Django-Pillow 8.0.1, Django-Werkzeug and OpenSSL installed.
One called CORK-DB: with MySQL server and MySQL Workbench installed.
One called Firewall SIRS: with iptables.

Setup instructions:
	
	CORK-WEB: 
		- Connect to the Firewall on switch one.
		- Check network connections (default gateway to firewall and database connection)
		- To run the application run $python3 /manage.py runserver_plus [certificate info] [host address]:[PORT]
	
	CORK-DB:
		- Connect to the Firewall on switch two.
		- Check network connections (default gateway to firewall and webserver connection)
		
	Firewall SIRS:
		- Connected to both switches and acting as gateway between networks
		- Apply iptable rules (Since for some reason we can't make them persistent)
		
			$/sbin/iptables -t nat -A PREROUTING --dst 192.168.1.12 -p tcp --dport 8000 -j DNAT --to-destination 192.168.0.254:8000
			$ iptables -A FORWARD -p tcp -s 192.168.2.4 --sport 3306 -d 192.168.0.254 --dport 1024:65535 -m state --state      ESTABLISHED -j ACCEPT
			$ iptables -A FORWARD -p tcp -s 192.168.0.254 --sport 1024:65535 -d 192.168.2.4 --dport 3306 -m state --state NEW, ESTABLISHED -j ACCEPT
			$ iptables -A FORWARD -i enp0s3 -o enp0s8 -j ACCEPT
			$ iptables -A FORWARD -o enp0s3 -i enp0s8 -j ACCEPT
			$ iptables -A FORWARD -j DROP
			
Application Access:
	- Browse https://[Firewall Address]:8000 and follow the UI looking at restaurants, making reservations and creating vouchers.
